import { Component } from "@angular/core";

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Pipes</h1>
            </div>

            <list [personList]=pList></list>
            <hr/>
            <h2>{{name}}</h2>
            <h2>{{name | uppercase}}</h2>
            <h2>{{name | capitalize}}</h2>

            <h2>{{today}}</h2>
            <h2>{{today | date}}</h2>
            <h2>{{today | date:'shortTime'}}</h2>
            <h2>{{today | date:'shortDate'}}</h2>
        </div>
    `
})
export class RootComponent {
    pList: Array<string>;
    name: string;
    today: Date;

    constructor() {
        this.pList = ["Manish", "Abhijeet", "Kedar", "Avinash", "Mohit", "Ashish", "Ankur", "Kumud"];
        this.name = "manish sharma";
        this.today = new Date();
    }
}